function getAjax(url, method, obj)
{
    return $.ajax({
        method: method,
        async: false,
        url: url,
        data :  obj,
        success: function (result) {
            //console.log("getAjax : " , result);
        },
        error: function (result) {
            console.log('Error:', result);
        }
    });
}

function getExcelAjax(url, method, obj)
{
    $.ajax({
        method: method,
        async: false,
        url: url,
        data :  obj,
        success: function (result) {
            var f = document.createElement('form');
            f.action=url;
            f.method='POST';
            f.target='_blank';
            $.each(obj.search[0], function(key, value)
            {
                var i = document.createElement('input');
                i.type = 'hidden';
                i.name = key;
                i.value = value;
                f.appendChild(i);
            });
            document.body.appendChild(f);
            f.submit();
        },
        error: function (result) {
            console.log('Error:', result);
        }
    });
}
// jquery extend function

function getFileAjax(url, method, obj)
{
    return $.ajax({
        async: false,
        url: url,
        data :  obj,
        type: method,
        processData:false,
        contentType:false,
        success: function (result) {
        },
        error: function (result) {
            console.log('Error:', result);
        }
    });
}
function setPostAjax(url, method, ids)
{
    var formData = new FormData();
    for(var i=0;i<ids.length;i++)
    {
        if($('#' + ids[i].id)[0].localName == 'input') {
            if ($('#' + ids[i].id).attr('type') == 'hidden') {
                formData.append(ids[i].id.replaceAll('detail_', ''), $('#' + ids[i].id).val());
            }
            else if ($('#' + ids[i].id).attr('type') == 'text') {
                formData.append(ids[i].id.replaceAll('detail_', ''), $('#' + ids[i].id).val());
            }
            else if ($('#' + ids[i].id).attr('type') == 'password') {
                formData.append(ids[i].id.replaceAll('detail_', ''), $('#' + ids[i].id).val());
            }
            else if ($('#' + ids[i].id).attr('type') == 'checkbox') {
                formData.append(ids[i].id.replaceAll('detail_', ''), $('#' + ids[i].id).is(":checked").toString());
            }
            else if ($('#' + ids[i].id).attr('type') == 'radio') {
                formData.append(ids[i].id.replaceAll('detail_', ''), $('#' + ids[i].id).is(":checked").toString());
            }
            else if ($('#' + ids[i].id).attr('type') == 'file') {
                if($('input[id="' + ids[i].id + '"]').val() != '') {
                    formData.append(ids[i].id.replaceAll('detail_', ''), $('input[id="' + ids[i].id + '"]')[0].files[0]);
                }
            }
        }
        else if($('#' + ids[i].id)[0].localName == 'select') {
            formData.append(ids[i].id.replaceAll('detail_', ''), $('#' + ids[i].id + ' option:selected').val());
        }
        else if($('#' + ids[i].id)[0].localName == 'textarea') {
            formData.append(ids[i].id.replaceAll('detail_', ''), $('#' + ids[i].id).val());
        }

    }
    return $.ajax({
        async: false,
        url: url,
        data :  formData,
        type: method,
        processData:false,
        contentType:false,
        success: function (result) {
        },
        error: function (result) {
            console.log('Error:', result);
        }
    });
}
function getSearch(search_form_id)
{
    if(search_form_id == null) {
        var ids = $("#search_form [id^='search_']");
        var search = "{";
        for (var i = 0; i < ids.length; i++) {
            search += '"' + ids[i].id.substring(7) + '":"' + $('#' + ids[i].id).val() + '"';
            if (i < ids.length - 1) {
                search += ",";
            }
        }
        search += "}";
        search = JSON.parse(search);
        return search;
    }
    else
    {
        var ids = $("#" + search_form_id + " [id^='search_']");
        var search = "{";
        for (var i = 0; i < ids.length; i++) {
            search += '"' + ids[i].id.substring(7) + '":"' + $('#' + ids[i].id).val() + '"';
            if (i < ids.length - 1) {
                search += ",";
            }
        }
        search += "}";
        search = JSON.parse(search);
        return search;
    }
}
function checkRequired(form_id)
{
    var check_required = true;
    var error_id = "";
    var required_ids = [];
    var ids = $("#" + form_id +" [id^='"+form_id+"_']");
    var cnt = 0;
    for(var i=0;i<ids.length;i++)
    {
        if($('#' + ids[i].id).hasClass('required'))
        {
            required_ids[cnt++] = ids[i].id;
        }
    }
    for(var i=0;i<required_ids.length;i++)
    {
        if($('#'+required_ids[i]).val() == '')
        {
            check_required = false;
            error_id = required_ids[i];
            break;
        }
        else
        {
            $('#' + required_ids[i]).removeClass('error');
            $('#' + required_ids[i]).addClass('check');
        }
    }
    if(!check_required)
    {
        alert($('#div_'+error_id ).text() + "는(은) 필수 값 입니다.");
        $('#' + error_id).removeClass('check');
        $('#' + error_id).addClass('error');
        $('#' + error_id).focus();
    }
    return check_required;

}
function checkDuplicate(form_id, url)
{
    var check_duplicate = true;
    var error_id = "";
    var duplicate_ids = [];
    var ids = $("#" + form_id +" [id^='"+form_id+"_']");
    var cnt = 0;
    for(var i=0;i<ids.length;i++)
    {
        if($('#' + ids[i].id).hasClass('duplicate'))
        {
            duplicate_ids[cnt++] = ids[i].id;
        }
    }
    for(var i=0;i<duplicate_ids.length;i++)
    {
        var value = $('#'+duplicate_ids[i]).val()
        var temp = duplicate_ids[i].split('_');
        var temp_field_name = temp[2] + '_' + temp[3];
        if(IsNullorEmpty(url))
        {
            url = window.location.href.split('/');
            url = url[url.length-1];
        }
        var data_list = getAjax(url + '/checkDuplicate', 'post', {field_name : temp_field_name,value : value}).responseText;
        if(data_list>0)
        {
            check_duplicate = false;
            error_id = duplicate_ids[i];
            break;
        }
        else
        {
            $('#' + duplicate_ids[i]).removeClass('error');
            $('#' + duplicate_ids[i]).addClass('check');
        }
    }
    if(!check_duplicate)
    {
        alert($('#div_'+error_id ).text() + "는(은) 중복되었습니다.");
        $('#' + error_id).removeClass('check');
        $('#' + error_id).addClass('error');
        $('#' + error_id).focus();
    }
    return check_duplicate;

}
function startSearch(key)
{
    if(key.keyCode == 13)
    {
        getList();
    }
}
function excelDwonload(id, title_name)
{
    $("#" + id).table2excel({
        exclude: ".noExl",
        name: title_name,
        filename: title_name + '_' + new Date().toISOString().replace(/[\-\:\.]/g, "").substring(0,8),
        fileext: ".xls",
        exclude_img: true,
        exclude_links: true,
        exclude_inputs: true
    });
}
function commapoint_format(data, type, data_type) {
    var str = '';
    var str1 = '';
    var str2 = '';
    var minus = '';
    var point = '';
    //데이터 타입에 따라 데이터 스트링으로 변환
    if (jQuery.type(data) == 'object') {
        str = (data.value).toString();
    }
    else if (jQuery.type(data) == 'string') {
        str = data;
    }
    else if (jQuery.type(data) == 'text') {
        str = data.value.toString();
    }
    while (true) {
        if (str.indexOf(' ') > -1) {
            str = str.replace(' ', "");
        }
        else {
            if (str.substring(0, 1) == '-') {
                minus = '-';
                str = str.substring(1, str.length);
            }
            else {
                if (str.length >= 2) {
                    if (str.substring(0, 2) == '00') {
                        str = '0' + str.substring(2, str.length);
                    }
                    else if (str.substring(0, 2) != '0.' && str.substring(0, 1) == '0') {
                        str = str.substring(1, str.length);
                        str1 = str;
                    }
                    else if (str.indexOf('.') > -1) {
                        point = '.';
                        str1 = str.substring(0, str.indexOf('.'));
                        str2 = str.substring(str.indexOf('.'), str.length);
                        str2 = str2.replace(/[^0-9]/gi, "");
                        break;
                    }
                    else {
                        str1 = str.replace(/[^0-9]/gi, "");
                        break;
                    }
                }
                else {
                    str1 = str.replace(/[^0-9.]/gi, "");
                    str = str.replace(/[^0-9.]/gi, "");
                    break;
                }
            }
        }
    }
    if (type == 0) {
        str1 = str1.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        if (data_type == "int") {
            str = str1;
        }
        else if (data_type == 'float') {
            str1 = str1 ? str1 : '0';
            str = str1 + point + str2;
        }
        else if (data_type.indexOf('float') >= 0) {
            var cut_number = parseInt(data_type.substring(5, 6));
            str1 = str1 ? str1 : '0';
            if (str2.length > cut_number) {
                str2 = str2.substring(0, cut_number);
            }
            str = str1 + point + str2;
        }
    }
    else if (type == 1) {
        str1 = str1.replace(/[^0-9]/gi, "");
        if (data_type == "int") {
            str = str1;
        }
        else if (data_type == 'float') {
            str1 = str1 ? str1 : '0';
            str = str1 + point + str2;
        }

    }
    if (str == '') {
        str = 0;
    }
    if (jQuery.type(data) == 'object') {
        data.value = minus + str;
    }
    else {
        return minus + str;
    }
}
function showZipCode(zipcode_id, main_addr_id)
{
    new daum.Postcode({
        oncomplete: function(data) {
            $('#' + main_addr_id).val(data.address);
            $('#' + zipcode_id).val(data.zonecode);
        }
    }).open();
}
function setAutoTableWidth(table_id, height)
{
    if(IsNullorEmpty(height))
    {
        height = '580';
    }
    var total_width = 0;
    for(var i=0;i<$('#'+table_id+' thead tr th').length;i++)
    {
        total_width += parseInt($('#'+table_id+' thead tr th')[i].style.width.replace('px', '').trim());
    }
    $('#'+table_id).attr('style', 'width:' + total_width + 'px;');
    $('#'+table_id + ' #data_list').attr('style', 'width:' + (total_width+20) + 'px;height:'+height+'px;');
}
function getTheadWidth(table_id)
{
    var widths = [];
    for(var i=0;i<$('#'+table_id+' thead tr th').length;i++)
    {
        widths[i] = parseInt($('#'+table_id+' thead tr th')[i].style.width.replace('px', '').trim());
    }
    return widths;
}
function getSystemCodeList(p_code,option)
{
    var data_list = getAjax('/a001_system_code/getCodeList', 'post', {p_code : p_code,option : option}).responseText;
    return data_list;
}

function getCommonCodeList(p_code,option)
{
    var data_list = getAjax('/a002_common_code/getCodeList', 'post', {p_code : p_code,option : option}).responseText;
    return data_list;
}

function setRowSelected(table_id, obj, option)
{
    if(option == 'select') {
        $('#' + table_id + ' tr').attr('style', 'background:');
        $('#' + table_id + ' #' + obj).attr('style', 'background:#e1faff');
    }
    else if(option == 'none') {
        $('#' + table_id + ' tr').attr('style', 'background:');
    }
}
function IsNullorEmpty(value) {
    return (!value || value == undefined || value == "" || value.length == 0 || value == "null" || value == null);
}
function getFormDatanMultipleFiles(form_id, form_data)
{
    var key_text = form_id + "_";
    // var ids = $('#' + form_id + ' [id^="'+key_text+'"]');

    var ids = $('[id^="'+key_text+'"]');
    // var form_data = new FormData(document.getElementById('write_form'));
    // var form = $('#' + form_id)[0];
    if(form_data == null)
    {
        console.log('reset');

        form_data = new FormData();
    }
    // var form_data123 = new FormData(form);
    for(var i=0;i<ids.length;i++)
    {
        if(ids[i].type == 'text') {
            form_data.append(ids[i].id.replace(key_text, '').toString(), $('#' + ids[i].id).val());
        }
        else if(ids[i].type == 'password') {
            form_data.append(ids[i].id.replace(key_text, '').toString(), $('#' + ids[i].id).val());
        }
        else if(ids[i].type == 'email') {
            form_data.append(ids[i].id.replace(key_text, '').toString(), $('#' + ids[i].id).val());
        }
        else if(ids[i].type == 'hidden') {
            form_data.append(ids[i].id.replace(key_text, '').toString(), $('#' + ids[i].id).val());
        }
        else if(ids[i].type == 'select-one') {
            form_data.append(ids[i].id.replace(key_text, '').toString(), $('#' + ids[i].id + ' option:selected').val());
        }
        else if(ids[i].type == 'radio') {
            form_data.append(ids[i].id.replace(key_text, '').toString(), $('input:radio[name="' + ids[i].id + '"]:checked').val());
        }
        else if(ids[i].type == 'file') {
            for(var j=0;j<$('#' + ids[i].id)[0].files.length;j++) {
                form_data.append(ids[i].id.replace(key_text, '').toString() + '_' + j, $('#' + ids[i].id)[0].files[j]);
            }
        }
    }
    // ids = $('[id^="'+key_text+'"]');
    // console.log(ids);
    // for(var i=0;i<ids.length;i++)
    // {
    //     if(ids[i].type == 'file') {
    //         for(var j=0;j<$('#' + ids[i].id)[0].files.length;j++) {
    //             form_data.append('file' + '_' + j, $('#' + ids[i].id)[0].files[j]);
    //         }
    //     }
    // }
    return form_data;
}
function setThead(table_id, json)
{
    var thead_list = [];
    if(IsNullorEmpty(json))
    {
        //ajax로 테이블 헤더 정보를 받거나 여기서 직접 설정
        // thead_list[0] = {id : 'no', style : 'width:80px;', name : '번호'};
        // thead_list[1] = {id : 'company_code', style : 'width:150px;', name : '업체코드'};
        // thead_list[2] = {id : 'company_name', style : 'width:200px;', name : '업체명'};
        // thead_list[3] = {id : 'company_type', style : 'width:100px;', name : '업체타입'};
        // thead_list[4] = {id : 'business_number', style : 'width:200px;', name : '사업자번호'};
        // thead_list[5] = {id : 'ceo_name', style : 'width:120px;', name : '업체대표'};
        // thead_list[6] = {id : 'phone', style : 'width:150px;', name : '전화번호'};
        // thead_list[7] = {id : 'fax', style : 'width:150px;', name : '팩스'};
        // thead_list[8] = {id : 'manager_name', style : 'width:120px;', name : '담당자명'};
        // thead_list[9] = {id : 'manager_phone', style : 'width:150px;', name : '담당자연락처'};
        // thead_list[10] = {id : 'manager_email', style : 'width:200px;', name : '담당자이메일'};
        // thead_list[11] = {id : 'company_use_yn', style : 'width:120px;', name : '거래처상태'};
    }
    else
    {
        thead_list = json;
    }
    var html = "";
    for(var i=0;i< thead_list.length;i++)
    {
        html += '<th id="' + thead_list[i].id + '" style="' + thead_list[i].style + '">' + thead_list[i].name + '</th>\n';
    }
    $('#' + table_id + " thead tr").html(html);
}
function getThead(table_id)
{
    var thead_id = $('#' + table_id + ' thead tr th');
    return thead_id;
}
function setDataList(table_id, ajax_url, search, column_ids, showdetailtype, detail_form_id, showtype, rowselect, import_option)
{
    var data_list = getAjax(ajax_url, 'post', {search : search}).responseText;
    if(data_list)
    {
        data_list = JSON.parse(data_list);
        if(import_option == 'datatable')
        {
            setdatatable.clear().draw();
            for (var i = 0; i < data_list.length; i++) {
                var rows = [];
                for (var j = 0; j < column_ids.length; j++) {
                    if (column_ids[j].id == 'no') {
                        rows[j] = data_list.length - i;
                    }
                    else {
                        rows[j] = (IsNullorEmpty(data_list[i][column_ids[j].id]) ? '' : data_list[i][column_ids[j].id]);
                    }
                }
                setdatatable.row.add(rows).draw( false );
            }
        }
        else {
            var html = "";
            var width = getTheadWidth(table_id);
            for (var i = 0; i < data_list.length; i++) {
                var onclick = "";
                if (!IsNullorEmpty(showdetailtype)) {
                    onclick += showdetailtype + "('" + data_list[i].idx + "', '" + detail_form_id + "');";
                }
                if (!IsNullorEmpty(showtype)) {
                    onclick += showtype + "('show');";
                }
                if (rowselect) {
                    onclick += "setRowSelected('" + table_id + "', '" + data_list[i].idx + "', 'select');";
                }
                html += '<tr id="' + data_list[i].idx + '" onclick="' + onclick + '">\n';
                for (var j = 0; j < column_ids.length; j++) {
                    if (column_ids[j].id == 'no') {
                        html += "\t<td style='width:" + width[j] + "px;' id='" + column_ids[j].id + "'  name='" + column_ids[j].id + "'>" + (data_list.length - i) + "</td>\n";
                    }
                    else {
                        html += "\t<td style='width:" + width[j] + "px;' id='" + column_ids[j].id + "'  name='" + column_ids[j].id + "'>" + (IsNullorEmpty(data_list[i][column_ids[j].id]) ? '' : data_list[i][column_ids[j].id]) + "</td>\n";
                    }
                }
                html += "</tr>\n";
            }
            $('#' + table_id + ' #data_list').html(html);
        }
    }
}
//한줄데이터 가져오기
function getDataListRow(table_id, row_index)
{
    // console.log($('#' + table_id + ' tbody tr').eq(row_index)[0].cells);
    return $('#' + table_id + ' tbody tr').eq(row_index)[0].cells;
}
function getDataListRows(table_id,  start_row_index, end_row_index, get_count)
{

    var table_data = $('#' + table_id + ' tbody tr');
    var cells = [];
    for( var i=0;i<table_data.length;i++)
    {
        cells[i] = table_data.eq(i)[0].cells;
    }
    return cells;
}
function getDataListAllRows(table_id)
{
    var table_data = $('#' + table_id + ' tbody tr');
    var cells = [];
    for( var i=0;i<table_data.length;i++)
    {
        cells[i] = table_data.eq(i)[0].cells;
    }
    return cells;
}

var file_formData = new FormData();
function getDropZoneFile(type)
{
    if(type == 'formdata')
    {
        return file_formData;
    }
    else if(type == "server")
    {

    }
}
function setDropZone(div_id, url, method, paramName, max_upfile_ea)
{
    formData = new FormData();
    var myDropzone = $('#' + div_id).dropzone({
        url: (IsNullorEmpty(url)? '/' : url),   //url을 적으면 파일을 바로전송 '/'만 넣게되면 전송하지않음
        method:(IsNullorEmpty(method)? '/' : method),
        uploadMultiple : true,
        paramName: paramName,
        createImageThumbnails : true,
        maxFilesize: 20, // MB
        maxFiles: max_upfile_ea,
        parallelUploads: max_upfile_ea,
        addRemoveLinks: true,
        // init: function() {
        //     // this.on("addedfile", function(event) {
        //
        //     // });
        // },
        addedfile: function(file) {
            if(this.files.length > max_upfile_ea)
            {
                this.files.splice(max_upfile_ea);
            }
            // Now attach this new element some where in your page
        },
        accept: function(file, done) {
            done(); //accept가 승인이나면 sending 이벤트로넘어간다.
        },
        sending: function(file, xhr, formData) {
            // file_formData = new FormData();
            for(var i=0;i<this.files.length;i++) {

                file_formData.append(paramName + '[]', this.files[i]);
            }
            for(var i=0;i<this.files.length;i++) {

                $('#' + div_id + ' #' + div_id + '_' + i).remove();
            }
            for(var i=0;i<this.files.length;i++) {
                var show_list = "";
                if (this.files[i].type.indexOf('image') < 0) {
                    var temp_name = this.files[i].name.split('.');

                    show_list = "<div class=\"card mb-1 shadow-none border border-light ml-2 mr-2\" id=\"" + div_id + "_" + i +"\">\n" +
                        "            <div class=\"p-2\">\n" +
                        "                <div class=\"row align-items-center\">\n" +
                        "                    <div class=\"col-auto\">\n" +
                        "                        <div class=\"avatar-sm\">\n" +
                        "                            <span class=\"avatar-title rounded\">\n" +
                        "                                ." + temp_name[temp_name.length - 1].toString().toUpperCase() + "\n" +
                        "                            </span>\n" +
                        "                        </div>\n" +
                        "                    </div>\n" +
                        "                    <div class=\"col pl-0\">\n" +
                        "                        <a href=\"javascript:void(0);\" class=\"text-muted font-weight-bold\">" + this.files[i].name + "</a>\n" +
                        "                        <p class=\"mb-0\">2.3 MB</p>\n" +
                        "                    </div>\n" +
                        "                    <div class=\"col-auto\">\n" +
                        "                        <!-- Button -->\n" +
                        "                        <a class=\"dz-remove\" href=\"javascript:$('#" + div_id + " #" + div_id + "_" + i + "').remove();this.files.splice('"+i+"', 1);\" data-dz-remove=\"\">\n" +
                        "                            <i class=\"dripicons-cross\"></i>\n" +
                        "                        </a>\n" +
                        "                    </div>\n" +
                        "                </div>\n" +
                        "            </div>\n" +
                        "        </div>\n";
                }
                else if (this.files[i].type.indexOf('image') >= 0) {
                    show_list = "<div class=\"card mb-1 shadow-none border border-light ml-2 mr-2\" id=\"" + div_id + "_" + i +"\">\n" +
                        "            <div class=\"p-2\">\n" +
                        "                <div class=\"row align-items-center\">\n" +
                        "                    <div class=\"col-auto\">\n" +
                        "                        <div class=\"avatar-sm\">\n" +
                        "                            <img src=\"" + this.files[i].dataURL + "\" width=\"50px\">\n" +
                        "                        </div>\n" +
                        "                    </div>\n" +
                        "                    <div class=\"col pl-0\">\n" +
                        "                        <a href=\"javascript:void(0);\" class=\"text-muted font-weight-bold\">" + this.files[i].name + "</a>\n" +
                        "                        <p class=\"mb-0\">2.3 MB</p>\n" +
                        "                    </div>\n" +
                        "                    <div class=\"col-auto\">\n" +
                        "                        <!-- Button -->\n" +
                        "                        <a class=\"dz-remove\" href=\"javascript:$('#" + div_id + " #" + div_id + "_" + i + "').remove();this.files.splice('"+i+"', 1);\" data-dz-remove=\"\">\n" +
                        "                            <i class=\"dripicons-cross\"></i>\n" +
                        "                        </a>\n" +
                        "                    </div>\n" +
                        "                </div>\n" +
                        "            </div>\n" +
                        "        </div>\n";
                }
                $('#' + div_id).append(show_list);
            }
        },
        thumbnail: function(file, dataUrl) {
            // Display the image in your file.previewElement
            for(var i=0;i<this.files.length;i++) {

                $('#' + div_id + ' #' + div_id + '_' + i).remove();
            }
            for(var i=0;i<this.files.length;i++) {
                var show_list = "";
                if (this.files[i].type.indexOf('image') < 0) {
                    var temp_name = this.files[i].name.split('.');

                    show_list = "<div class=\"card mb-1 shadow-none border border-light ml-2 mr-2\" id=\"" + div_id + "_" + i +"\">\n" +
                        "            <div class=\"p-2\">\n" +
                        "                <div class=\"row align-items-center\">\n" +
                        "                    <div class=\"col-auto\">\n" +
                        "                        <div class=\"avatar-sm\">\n" +
                        "                            <span class=\"avatar-title rounded\">\n" +
                        "                                ." + temp_name[temp_name.length - 1].toString().toUpperCase() + "\n" +
                        "                            </span>\n" +
                        "                        </div>\n" +
                        "                    </div>\n" +
                        "                    <div class=\"col pl-0\">\n" +
                        "                        <a href=\"javascript:void(0);\" class=\"text-muted font-weight-bold\">" + this.files[i].name + "</a>\n" +
                        "                        <p class=\"mb-0\">2.3 MB</p>\n" +
                        "                    </div>\n" +
                        "                    <div class=\"col-auto\">\n" +
                        "                        <!-- Button -->\n" +
                        "                        <a class=\"dz-remove\" href=\"javascript:$('#" + div_id + " #" + div_id + "_" + i + "').remove();this.files.splice('"+i+"', 1);\" data-dz-remove=\"\">\n" +
                        "                            <i class=\"dripicons-cross\"></i>\n" +
                        "                        </a>\n" +
                        "                    </div>\n" +
                        "                </div>\n" +
                        "            </div>\n" +
                        "        </div>\n";
                }
                else if (this.files[i].type.indexOf('image') >= 0) {
                    show_list = "<div class=\"card mb-1 shadow-none border border-light ml-2 mr-2\" id=\"" + div_id + "_" + i +"\">\n" +
                        "            <div class=\"p-2\">\n" +
                        "                <div class=\"row align-items-center\">\n" +
                        "                    <div class=\"col-auto\">\n" +
                        "                        <div class=\"avatar-sm\">\n" +
                        // "                            <img src=\"" + this.files[i].dataURL + "\" width=\"50px\">\n" +
                        "                            <img src=\"" + dataUrl + "\" width=\"50px\">\n" +
                        "                        </div>\n" +
                        "                    </div>\n" +
                        "                    <div class=\"col pl-0\">\n" +
                        "                        <a href=\"javascript:void(0);\" class=\"text-muted font-weight-bold\">" + this.files[i].name + "</a>\n" +
                        "                        <p class=\"mb-0\">2.3 MB</p>\n" +
                        "                    </div>\n" +
                        "                    <div class=\"col-auto\">\n" +
                        "                        <!-- Button -->\n" +
                        "                        <a class=\"dz-remove\" href=\"javascript:$('#" + div_id + " #" + div_id + "_" + i + "').remove();this.files.splice('"+i+"', 1);\" data-dz-remove=\"\">\n" +
                        "                            <i class=\"dripicons-cross\"></i>\n" +
                        "                        </a>\n" +
                        "                    </div>\n" +
                        "                </div>\n" +
                        "            </div>\n" +
                        "        </div>\n";
                }
                $('#' + div_id).append(show_list);
            }
        },
        uploadprogress: function(file, progress, bytesSent) {
            console.log(file_formData.getAll('files[]'));
        },
    });
}
function getNowDateTime(date, time, milli)
{
    var today = new Date();

    var year = today.getFullYear(); // 년도
    var month = today.getMonth() + 1;  // 월
    var date = today.getDate();  // 날짜
    var day = today.getDay();  // 요일

    var hours = today.getHours(); // 시
    var minutes = today.getMinutes();  // 분
    var seconds = today.getSeconds();  // 초
    var milliseconds = today.getMilliseconds(); // 밀리초
    var return_date = '';
    if(date)
    {
        return_date += year;
        return_date += '-' + month;
        return_date += '-' + date;
    }
    if(time)
    {
        if(return_date != '')
        {
            return_date += ' ';
        }
        return_date += hours;
        return_date += ':' + minutes;
        return_date += ':' + seconds;
    }
    if(milli)
    {
        if(return_date != '')
        {
            return_date += '.';
        }
        return_date += milliseconds;
    }
    return return_date;
}
function setSingleDatePicker(reset, setDate) {
    $('.single-date').daterangepicker({
        locale:{format:'YYYY-MM-DD',
            monthNames:['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
            daysOfWeek:['일','월','화','수','목','금','토'] },
        singleDatePicker: true,
        showDropdowns: true
    });
    if(reset) $('.single-date').val('');
    else {
        if(setDate != '') $('.single-date').val(setDate);
    }
}
function setDatePicker(today)
{
    if(today)
    {
        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            viewMode: 'years',
            autoclose: true,
            language : "ko"
        });
        $('.datepicker').val(getNowDateTime(true,false,false));
    }
    else
    {
        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            viewMode: 'years',
            autoclose: true,
            language : "ko"
        });
    }
}
/*
데이터 데이블 관련 함수
*/
//데이타 테이블 설정
var setdatatable = null;
function setDataTable(type)
{
    if(type == 'main_list') {
        var events = $('#events');
        setdatatable = $('.data-tables').DataTable({
            "scrollX": true,
            scrollY: '50vh',
            scrollCollapse: true,
            select: true,
            "order": [[0, "desc"]]
        });

        $('.data-tables tbody').on('click', 'tr', function () {
            if ($(this).hasClass('selected')) {
                $(this).removeClass('selected');
                showVerticalWriteForm('close');
            }
            else {
                setdatatable.$('tr.selected').removeClass('selected');
                $(this).addClass('selected');
                showVerticalWriteForm('show');
            }
        });
    }
}
/* 선언된 datatable 변수,숨길 칼럼의 순번 0부터 숨길지보일 여부 true/false */
//칼럼 보이기 & 숨기기
function setVisibleColumn(datatable, column_idx, type)
{
    var column = datatable.column(column_idx);

    if(type == true)
    {
        column.visible(column.visible());
    }
    else
    {
        column.visible(!column.visible());
    }
}

//메뉴 나타내기 작게하기
function changeMenu()
{
    if($('#btn_changeMenu').hasClass('mdi-arrow-left-bold'))
    {
        $('#btn_changeMenu').removeClass('mdi-arrow-left-bold');
        $('#btn_changeMenu').addClass('mdi-arrow-right-bold');
        $(document.body).addClass('enlarged');
    }
    else if($('#btn_changeMenu').hasClass('mdi-arrow-right-bold'))
    {
        $(document.body).removeClass('enlarged');
        $('#btn_changeMenu').removeClass('mdi-arrow-right-bold');
        $('#btn_changeMenu').addClass('mdi-arrow-left-bold');
    }
}

function table_select_tr(table_id)
{
    $('#' + table_id + ' tbody tr').mouseover(function(){
        $(this).addClass('select_row');

    });
    $('#' + table_id + ' tbody tr').mouseout(function() {
        if(!$(this).hasClass('click'))
        {
            $(this).removeClass('select_row');

        }

    });
    $('#' + table_id + ' tbody tr').click(function() {
        $('#' + table_id + ' *').removeClass('click');
        $('#' + table_id + ' *').removeClass('select_row');
        $(this).addClass('select_row');
        $(this).addClass('click');

    });
}
function table_select_num(num)
{
    $('#' + table_id + ' tbody tr').mouseover(function(){
        $(this).addClass('select_row');

    });
    $('#' + table_id + ' tbody tr').mouseout(function() {
        if(!$(this).hasClass('click'))
        {
            $(this).removeClass('select_row');

        }

    });
    $('#' + table_id + ' tbody tr').click(function() {
        $('#' + table_id + ' *').removeClass('click');
        $('#' + table_id + ' *').removeClass('select_row');
        $(this).addClass('select_row');
        $(this).addClass('click');

    });
}

function setWidth(id, set_id)
{
    var tds = $('#' + id + " tr td");
    for(var i=0;i<tds.length;i++)
    {
        if(i >= (tds.length-1))
        {
            $('#' + set_id + " tr th:eq(" + i + ")").width(($('#' + id + " tr td:eq(" + i + ")").width()+17));
        }
        else {
            $('#' + set_id + " tr th:eq(" + i + ")").width($('#' + id + " tr td:eq(" + i + ")").width());
        }
    }
}