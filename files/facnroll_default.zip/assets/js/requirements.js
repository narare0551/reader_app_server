requirejs.config({
	//baseUrl: 'bower_components'
	// paths: {
 //        app: '../app'
 //    }
})

require[('test')];